import { Image } from 'expo-image';
import { Platform, StyleSheet } from 'react-native';

import { HelloWave } from '@/components/HelloWave';
import ParallaxScrollView from '@/components/ParallaxScrollView';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { View, TextInput, Button } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useState } from 'react';

export default function HomeScreen() {
  const [peso, setPeso] = useState('');
  const [altura, setAltura] = useState('');
  const [sexo, setSexo] = useState('Masculino');
  const [resultado, setResultado] = useState('null');
  const [categoria, setCategoria] = useState('');

function calculoIMC(){
    if (! peso || ! altura){
    setResultado("Viado escreva direito!!!");
    setCategoria('Preencha os campos de peso e altura!!');
    return;
  }

  const alturaM = parseFloat(altura) / 100;
  const imc = parseFloat(peso) / (alturaM * alturaM);

  setResultado(imc.toFixed(2));

     if (imc < 19.1) setCategoria('Abaixo do peso');
     else if (imc < 25.8) setCategoria('Peso normal');
     else if (imc < 27.3) setCategoria('Sobrepeso');
     else if (imc < 32.3) setCategoria('Obesidade nível 1');
     else if (imc < 35.6) setCategoria('Obesidade nível 2');
     else setCategoria('Obesidade nível 3');
}


  return (
    <ParallaxScrollView
      headerBackgroundColor={{ light: '#A1CEDC', dark: '#1D3D47' }}
      headerImage={
        <Image
          source={require('@/assets/images/partial-react-logo.png')}
          style={styles.reactLogo}
        />
      }>
      <ThemedView style={styles.titleContainer}>
        <ThemedText type="title">Bem-vindo!</ThemedText>
        <HelloWave />
      </ThemedView>
      <ThemedView style={styles.stepContainer}>
        <ThemedText type="subtitle">Calculo IMC</ThemedText>
        
        <TextInput
        style={styles.input}
        placeholder='Insira o seu peso (kg)'
        keyboardType='numeric'
        value={peso}
        onChangeText={setPeso}
        />
        <TextInput
        style={styles.input}
        placeholder='Insira a sua altura (cm)'
        keyboardType='numeric'
        value={altura}
        onChangeText={setAltura}
        />

      <Picker
        selectedValue={sexo}
        style={styles.input}
        onValueChange={(itemValue) => setSexo(itemValue)}      
      >
        <Picker.Item label="Masculino" value="masculino" />
        <Picker.Item label="Feminino" value="feminino" />
      </Picker>
        
      <Button title="Calcular IMC" onPress={calculoIMC} />

      {resultado && (
        <ThemedText >
          Seu IMC é: {resultado} - {categoria}
        </ThemedText>
      )}
      </ThemedView>
    </ParallaxScrollView>
  );
}

const styles = StyleSheet.create({
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  stepContainer: {
    gap: 8,
    marginBottom: 8,
  },
  reactLogo: {
    height: 178,
    width: 290,
    bottom: 0,
    left: 0,
    position: 'absolute',
  },
  input: {
    borderWidth: 2,
    borderColor: '#ccc',
    padding: 10,
    borderRadius: 8,
    marginVertical: 5,
    backgroundColor: '#fff',
    width: 600,
  }
});
